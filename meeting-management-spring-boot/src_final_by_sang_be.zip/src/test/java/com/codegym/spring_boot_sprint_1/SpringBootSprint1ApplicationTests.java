package com.codegym.spring_boot_sprint_1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootSprint1ApplicationTests {

    @Test
    void contextLoads() {
    }

}
