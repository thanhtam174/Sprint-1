package com.codegym.spring_boot_sprint_1;

public class Test {
    public static void main(String[] args) {
    }
}
