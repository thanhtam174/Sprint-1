//package com.codegym.spring_boot_sprint_1.service;
//
//import com.codegym.spring_boot_sprint_1.model.RoomBooking;
//
//import java.util.List;
//
//public interface IRoomBookingService {
//    List<RoomBooking> findAll();
//}
