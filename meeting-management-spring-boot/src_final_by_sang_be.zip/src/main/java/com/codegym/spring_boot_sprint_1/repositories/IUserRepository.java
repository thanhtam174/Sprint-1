package com.codegym.spring_boot_sprint_1.repositories;

import com.codegym.spring_boot_sprint_1.model.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Repository
public interface IUserRepository extends JpaRepository<User, Long> {
    @Query(value = "SELECT * " +
            "FROM users " +
            "INNER JOIN user_role " +
            "ON users.user_id=user_role.user_id " +
            "INNER JOIN roles " +
            "ON user_role.role_id=roles.role_id " +
            "INNER JOIN department " +
            "ON users.department_id=department.department_id ", nativeQuery = true)
    Page<User> findAllUser(Pageable pageable);

    @Query(value = "SELECT * " +
            "FROM users " +
            "INNER JOIN department " +
            "ON users.department_id=department.department_id " +
            "WHERE users.username LIKE %?1% " +
            "AND users.email LIKE %?2% " +
            "AND department.name LIKE %?3% ", nativeQuery = true)
    List<User> searchUser(String searchUsername, String searchEmail, String searchDepartment);

    @Query(value = "SELECT * " +
            "FROM users " +
            "WHERE users.user_id = ?1 ", nativeQuery = true)
    Optional<User> findById(Long id);

    @Modifying
    @Transactional
    @Query(value = " INSERT INTO users (email,`name`,`password`,username,department_id) " +
            "VALUE " +
            "(?1,?2,?3,?4,?5) ", nativeQuery = true)
    void saveUser(String email, String name, String password, String username, Long id);

    @Modifying
    @Transactional
    @Query(value = " INSERT INTO user_role (user_id, role_id) " +
            "VALUE " +
            "(?1,?2) ", nativeQuery = true)
    void setRoleForUser(Long userId, Integer roleId);

    @Query(value = "SELECT * " +
            "FROM users " +
            "WHERE users.email = ?1 ", nativeQuery = true)
    Optional<User> findUserByEmail(String email);

    Optional<User> findByUsername(String username);

    @Modifying
    @Transactional
    @Query(value = " UPDATE users " +
            "SET users.email = ?1, " +
            "users.name = ?2, " +
            "users.department_id = ?3 " +
            "WHERE users.user_id = ?4 ) ", nativeQuery = true)
    void updateUser(String email, String name, Long departmentId, Long userId);

    @Modifying
    @Transactional
    @Query(value = " UPDATE users " +
            "SET users.password = ?1 " +
            "WHERE users.user_id = ?2 ", nativeQuery = true)
    void updateUserPassword(String password, Long userId);
}
