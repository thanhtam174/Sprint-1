//package com.codegym.spring_boot_sprint_1.repositories;
//
//import com.codegym.spring_boot_sprint_1.model.RoomBooking;
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.data.jpa.repository.Query;
//import org.springframework.stereotype.Repository;
//
//import java.util.List;
//
//@Repository
//public interface IRoomBookingRepository extends JpaRepository<RoomBooking, Long> {
//    @Query(value = "select room_bookings.id,room_bookings.registration_date ,room_bookings.content, room_bookings.started_date, room_bookings.end_date from room_bookings", nativeQuery = true)
//    List<RoomBooking> findAll();
//}
