package com.codegym.spring_boot_sprint_1.model;

public class BookingCancellation {
}
