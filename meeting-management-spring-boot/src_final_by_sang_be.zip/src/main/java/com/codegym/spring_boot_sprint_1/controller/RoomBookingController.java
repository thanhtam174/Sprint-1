//package com.codegym.spring_boot_sprint_1.controller;
//
////import com.codegym.spring_boot_sprint_1.model.RoomBooking;
//import com.codegym.spring_boot_sprint_1.model.dto.RoomBookingDto;
//import com.codegym.spring_boot_sprint_1.service.IRoomBookingService;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.CrossOrigin;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//import java.util.ArrayList;
//import java.util.List;
//
//@RestController
//@RequestMapping("/roombooking")
//@CrossOrigin(origins = "http://localhost:4200/")
//public class RoomBookingController {
//    @Autowired
//    private IRoomBookingService roomBookingService;
//
//    @GetMapping
//    public ResponseEntity<List<RoomBookingDto>> getAllRoomBooking(){
//        List<RoomBooking> list = roomBookingService.findAll();
//        List<RoomBookingDto> dtoList = new ArrayList<>();
//        for (RoomBooking rb : list){
//            RoomBookingDto roomBookingDto = new RoomBookingDto();
//            roomBookingDto.setIdRoom(rb.getId());
//            roomBookingDto.setDescription(rb.getContent());
//            roomBookingDto.setLocation(rb.getContent());
//            roomBookingDto.setSubject(rb.getContent());
//            String tempSdt = rb.getStartedDate();
//            String tempSdt2 = tempSdt.replace(" ","T");
//            String startDateTime = tempSdt2.concat("Z");
//            roomBookingDto.setStartTime(startDateTime);
//
//            String tempEdt = rb.getEndDate();
//            String tempEdt2 = tempEdt.replace(" ","T");
//            String endDateTime = tempEdt2.concat("Z");
//            roomBookingDto.setEndTime(endDateTime);
//            dtoList.add(roomBookingDto);
//        }
//        return new ResponseEntity<>(dtoList,HttpStatus.OK);
//    }
//
//}
