//package com.codegym.spring_boot_sprint_1.model;
//
//import javax.persistence.*;
//
//@Entity
//@Table(name = "property")
//public class Property {
//
//    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    private Long id;
//
//    private String name;
//
//    private String detail;
//
//    private Double price;
//
//    private Integer amount;
//
//    private Integer using;
//
//    private Integer maintenance;
//
//    private Integer availability;
//
//    private String images;
//
//    private Integer amountInRoom;
//
//    public Property() {
//    }
//
//    public Long getId() {
//        return id;
//    }
//
//    public void setId(Long id) {
//        this.id = id;
//    }
//
//    public String getName() {
//        return name;
//    }
//
//    public void setName(String name) {
//        this.name = name;
//    }
//
//    public String getDetail() {
//        return detail;
//    }
//
//    public void setDetail(String detail) {
//        this.detail = detail;
//    }
//
//    public Double getPrice() {
//        return price;
//    }
//
//    public void setPrice(Double price) {
//        this.price = price;
//    }
//
//    public Integer getAmount() {
//        return amount;
//    }
//
//    public void setAmount(Integer amount) {
//        this.amount = amount;
//    }
//
//    public Integer getUsing() {
//        return using;
//    }
//
//    public void setUsing(Integer using) {
//        this.using = using;
//    }
//
//    public Integer getMaintenance() {
//        return maintenance;
//    }
//
//    public void setMaintenance(Integer maintenance) {
//        this.maintenance = maintenance;
//    }
//
//    public Integer getAvailability() {
//        return availability;
//    }
//
//    public void setAvailability(Integer availability) {
//        this.availability = availability;
//    }
//
//    public String getImages() {
//        return images;
//    }
//
//    public void setImages(String images) {
//        this.images = images;
//    }
//
//    public Integer getAmountInRoom() {
//        return amountInRoom;
//    }
//
//    public void setAmountInRoom(Integer amountInRoom) {
//        this.amountInRoom = amountInRoom;
//    }
//}
