package com.codegym.spring_boot_sprint_1.controller;

import com.codegym.spring_boot_sprint_1.model.dto.PasswordDto;
import com.codegym.spring_boot_sprint_1.model.dto.UserDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;
import com.codegym.spring_boot_sprint_1.model.User;
import com.codegym.spring_boot_sprint_1.service.IUserService;

import java.util.List;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*", maxAge = 3600)
@RequestMapping(value = "/api/user")
public class UserController {

    @Autowired
    private PasswordEncoder encoder;
    @Autowired
    private IUserService userService;

    @GetMapping("/user-list")
    public ResponseEntity<Page<User>> getListUser(Pageable pageable) {
        Page<User> userList = userService.findAll(pageable);
        if (userList.isEmpty()) {
            return new ResponseEntity<Page<User>>(HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<Page<User>>(userList, HttpStatus.OK);
    }

    @GetMapping("/user-search")
    @ResponseBody
    public List<User> getSearchList(@RequestParam String username, String email, String department) {
        return userService.searchUser(username, email, department);
    }

    @GetMapping("/user/{id}")
    @ResponseBody
    public User findUserById(@PathVariable("id") Long id) {
        return userService.findById(id);
    }

    @PostMapping("/user-save")
    public void saveUser(@RequestBody UserDto user) {
        UserDto userDto = new UserDto();
        userDto.setUsername(user.getUsername());
        userDto.setPassword(encoder.encode(user.getPassword()));
        userDto.setName(user.getName());
        userDto.setEmail(user.getEmail());
        userDto.setDepartment(user.getDepartment());
        userService.save(userDto.getEmail(), userDto.getName(),
                userDto.getPassword(), userDto.getUsername(),
                userDto.getDepartment());
        Long id = userService.findUserByEmail(userDto.getEmail()).getId();
        System.out.println(user.getRoles());
        userService.setRole(id, user.getRoles());
    }

    public void setRoleForUser(Long userId, String roleName) {
        Integer roleId;
        if ("admin".equals(roleName)) {
            roleId = 2;
        } else {
            roleId = 1;
        }
        userService.setRole(userId, roleId);
    }

    @PatchMapping("/user-change-password/{id}")
    @ResponseBody
    public void changeUserPassword(@PathVariable("id") Long id, @RequestBody PasswordDto passwordDto) {
        String oldPassword = passwordDto.getOldPassword();
        String newPassword = passwordDto.getNewPassword();
        User user = userService.findById(id);
        System.out.println(userPasswordCheck(oldPassword, user));
        userPasswordCheck(oldPassword, user);
        userService.updateUserPassword(encoder.encode(newPassword), id);

    }

    public boolean userPasswordCheck(String password, User user) {
        PasswordEncoder passencoder = new BCryptPasswordEncoder();
        String encodedPassword = user.getPassword();
        return passencoder.matches(password, encodedPassword);
    }

}

