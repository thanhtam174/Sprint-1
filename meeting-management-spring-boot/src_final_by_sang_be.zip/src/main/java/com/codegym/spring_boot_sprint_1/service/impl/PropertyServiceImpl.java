package com.codegym.spring_boot_sprint_1.service.impl;

import com.codegym.spring_boot_sprint_1.service.IPropertyService;
import org.springframework.stereotype.Service;

@Service
public class PropertyServiceImpl implements IPropertyService {
}
