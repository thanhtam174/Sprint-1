package com.codegym.spring_boot_sprint_1.repositories;

public interface IMeetingRoomRepository {
}
