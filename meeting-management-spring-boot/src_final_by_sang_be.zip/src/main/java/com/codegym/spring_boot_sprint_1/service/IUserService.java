package com.codegym.spring_boot_sprint_1.service;

import com.codegym.spring_boot_sprint_1.model.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface IUserService {

    Page<User> findAll(Pageable pageable);

    List<User> searchUser(String searchUsername, String searchEmail, String searchDepartment);

    User findById(Long id);

    User findUserByEmail(String email);

    void save(String email, String name, String password, String username, Long id);

    void setRole(Long userId, Integer roleId);

    void updateUserPassword(String password, Long userId);

    void remove(Long id);

    void updateUser(String email, String name, Long departmentId, Long userId);
}
