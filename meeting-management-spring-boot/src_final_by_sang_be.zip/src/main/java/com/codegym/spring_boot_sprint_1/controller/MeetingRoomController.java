package com.codegym.spring_boot_sprint_1.controller;

public class MeetingRoomController {
}
