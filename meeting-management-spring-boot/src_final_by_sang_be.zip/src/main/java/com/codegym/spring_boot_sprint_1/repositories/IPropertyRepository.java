package com.codegym.spring_boot_sprint_1.repositories;

import org.springframework.stereotype.Repository;

@Repository
public interface IPropertyRepository {
}
