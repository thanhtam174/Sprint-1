//package com.codegym.spring_boot_sprint_1.service.impl;
//
//import com.codegym.spring_boot_sprint_1.model.RoomBooking;
//import com.codegym.spring_boot_sprint_1.repositories.IRoomBookingRepository;
//import com.codegym.spring_boot_sprint_1.service.IRoomBookingService;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import java.util.List;
//
//@Service
//public class RoomBookingServiceImpl implements IRoomBookingService {
//    @Autowired
//    private IRoomBookingRepository roomBookingRepository;
//
//    @Override
//    public List<RoomBooking> findAll() {
//        return roomBookingRepository.findAll();
//    }
//}
