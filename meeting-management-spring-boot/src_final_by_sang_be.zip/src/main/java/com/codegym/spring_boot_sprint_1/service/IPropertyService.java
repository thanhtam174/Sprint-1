package com.codegym.spring_boot_sprint_1.service;


public interface IPropertyService {

}
